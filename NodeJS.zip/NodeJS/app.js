require('dotenv').config();
const express = require('express');
const { MongoClient, ObjectId } = require('mongodb'); // Use ObjectId from mongodb
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const port = process.env.PORT || 3007;
const mongoURI = process.env.MONGODB_URI;

const client = new MongoClient(mongoURI);
let collection;

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());

async function initializeDB() {
    try {
        await client.connect();
        const db = client.db('StudentDB');
        collection = db.collection('studentData');
        console.log("Connected to database");
    } catch (error) {
        console.error("Database connection failed:", error);
        process.exit(1);
    }
}

// Initialize the database connection once
initializeDB();

// API route to fetch users
app.get('/api/students', async (req, res) => {
    try {
        const { project, sortField, sortOrder = 'asc' } = req.query;
        const query = {};

        if (project) {
            query.project = project;
        }

        const sort = {};
        if (sortField) {
            sort[sortField] = sortOrder === 'asc' ? 1 : -1;
        }

        const result = await collection.find(query).sort(sort).toArray();
        res.json(result);
    } catch (error) {
        console.error("Failed to fetch data:", error);
        res.status(500).send("Internal Server Error");
    }
});

// API route to add a new employee
app.post('/api/students', async (req, res) => {
    try {
        const newStudent = req.body;
        const result = await collection.insertOne(newStudent);
        res.status(201).json(result);
    } catch (error) {
        console.error("Failed to add an employee:", error);
        res.status(500).send("Internal Server Error");
    }
});

// API route to delete an employee
app.delete('/api/students/:id', async (req, res) => {
    try {
        const studentId = req.params.id;

        // Validate that the ID is a 24-character hex string
        if (!ObjectId.isValid(studentId)) {
            return res.status(400).json({ message: 'Invalid ID format' });
        }

        const result = await collection.deleteOne({ _id: new ObjectId(studentId) });

        if (result.deletedCount === 1) {
            res.status(200).json({ message: 'Student deleted successfully' });
        } else {
            res.status(404).json({ message: 'Student not found' });
        }
    } catch (error) {
        console.error("Failed to delete Student:", error);
        res.status(500).send("Internal Server Error");
    }
});

// API route to update an student
app.put('/api/students/:id', async (req, res) => {
    try {
        const studentId = req.params.id;

        // Validate that the ID is a 24-character hex string
        if (!ObjectId.isValid(studentId)) {
            return res.status(400).json({ message: 'Invalid ID format' });
        }

        const updatedStudent = req.body;
        const result = await collection.updateOne(
            { _id: new ObjectId(studentId) },
            { $set: updatedStudent }
        );

        if (result.matchedCount === 1) {
            res.status(200).json({ message: 'Student updated successfully' });
        } else {
            res.status(404).json({ message: 'Student not found' });
        }
    } catch (error) {
        console.error("Failed to update Student:", error);
        res.status(500).send("Internal Server Error");
    }
});

app.listen(port, () => {
    console.log(`Server running at http://127.0.0.1:${port}`);
});
